﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOGO_DO_GALO_WPF
{
    public class Jogo_do_Galo
    {
        public int player { get; set; }

        private string[] galo = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

        public bool Play(int jogador,int pos)
        {
            if (int.TryParse(galo[pos-1],out int i)){
                if (jogador == 1)
                {
                    galo[pos - 1] = "X";
                    return true;

                }
                else
                {
                    galo[pos - 1] = "O";
                    return true;

                }
            }else
                return false;


        }

        public bool HasWon()
        {
            if (galo[0] == galo[1] && galo[1] == galo[2])
            {
                return true;
            }
            else if (galo[3] == galo[4] && galo[4] == galo[5])
            {
                return true;
            }
            else if (galo[6] == galo[7] && galo[7] == galo[8])
            {
                return true;
            }
            else if (galo[0] == galo[3] && galo[3] == galo[6])
            {
                return true;
            }
            else if (galo[1] == galo[4] && galo[4] == galo[7])
            {
                return true;
            }
            else if (galo[2] == galo[5] && galo[5] == galo[8])
            {
                return true;
            }
            else if (galo[0] == galo[4] && galo[4] == galo[8])
            {
                return true;
            }
            else if (galo[2] == galo[4] && galo[4] == galo[6])
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void ResetGame()
        {
            for (int i = 0; i < galo.Length; i++)
                galo[i] = (i+1).ToString();
        }


    }

}
