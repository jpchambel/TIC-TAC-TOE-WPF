﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JOGO_DO_GALO_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int Player = 1;
        public Jogo_do_Galo jogo;


        public bool win_test = false;
        public MainWindow()
        {

            InitializeComponent();
            Switch_Player();
            
            jogo = new Jogo_do_Galo();
            
            



    }

        private void Button_Quit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Reset_Game_Click(object sender, RoutedEventArgs e)
        {
            Reset_Game();
            
        }

        public void Button_1_Click(object sender, RoutedEventArgs e)
        {

            if (jogo.Play(Player, 1))
            {
                if (Player == 1)
                {
                    Button_1.Content = "X";
                }
                else
                {
                    Button_1.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }
        }

        private void Button_2_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 2))
            {
                if (Player == 1)
                {
                    Button_2.Content = "X";
                }
                else
                {
                    Button_2.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }
        }

        private void Button_3_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 3))
            {
                if (Player == 1)
                {
                    Button_3.Content = "X";
                }
                else
                {
                    Button_3.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }

        }

        private void Button_4_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 4))
            {
                if (Player == 1)
                {
                    Button_4.Content = "X";
                }
                else
                {
                    Button_4.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }

        }

        private void Button_5_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 5))
            {
                if (Player == 1)
                {
                    Button_5.Content = "X";
                }
                else
                {
                    Button_5.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }
        }

        private void Button_6_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 6))
            {
                if (Player == 1)
                {
                    Button_6.Content = "X";
                }
                else
                {
                    Button_6.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }
        }

        private void Button_7_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 7))
            {
                if (Player == 1)
                {
                    Button_7.Content = "X";
                }
                else
                {
                    Button_7.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }
        }

        private void Button_8_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 8))
            {
                if (Player == 1)
                {
                    Button_8.Content = "X";
                }
                else
                {
                    Button_8.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }
        }

        private void Button_9_Click(object sender, RoutedEventArgs e)
        {
            if (jogo.Play(Player, 9))
            {
                if (Player == 1)
                {
                    Button_9.Content = "X";
                }
                else
                {
                    Button_9.Content = "O";
                }
                if (jogo.HasWon())
                    HasWonMessage();
                Switch_Player();
            }




        }

        private void Switch_Player()
        {
            Check_State();
            if (Player == 1)
            {
                Player = 2;
                Current_Player.Content = "O";
            }
            else
            {
                Player = 1;
                Current_Player.Content = "X";
            }
        }

        private void Check_State()
        {
            if (Button_1.Content != null &&
            Button_2.Content != null &&
            Button_3.Content != null &&
            Button_4.Content != null &&
            Button_5.Content != null &&
            Button_6.Content != null &&
            Button_7.Content != null &&
            Button_8.Content != null &&
            Button_9.Content != null)
            {
                MessageBox.Show("Game Over!");
                Reset_Game();
            }
                
        }

        private void Reset_Game()
        {
            Button_1.Content = null;
            Button_2.Content = null;
            Button_3.Content = null;
            Button_4.Content = null;
            Button_5.Content = null;
            Button_6.Content = null;
            Button_7.Content = null;
            Button_8.Content = null;
            Button_9.Content = null;
            jogo.ResetGame();
        }

        private void HasWonMessage()
        {
            if (Player == 1)
                MessageBox.Show("Jogador X ganhou!");
            else
                MessageBox.Show("Jogador O ganhou!");

            Reset_Game();
            jogo.ResetGame();

        }

    }
}
